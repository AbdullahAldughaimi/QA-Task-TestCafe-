import { Selector } from "testcafe";
 
fixture `Sign in`
 .page ('http://localhost/carrental/login-user.php')
 // Valid Credentials 
 test('Login and logout user with a valid email & password', async t=>{
await t 
   .typeText(Selector('#email'), 'abd1810000@hotmail.com')
   .typeText(Selector('#password'), '12345678Aa')
   .click(Selector('#blogin'))
   .wait(5000)
   .expect(Selector('H2').withExactText('Cars').exists).ok()
   .click(Selector('#logout'))

   .expect(Selector('H2').withExactText('Login').exists).ok();

 })
 // Invalid Email & Password

 test('Login user with  invalid email & password', async t=>{
await t 
   .typeText(Selector('#email'), 'test@hotmail.com')
   .typeText(Selector('#password'), '12345678bb')
   .click(Selector('#blogin'))
   .wait(5000)
   .expect(Selector('H2').withExactText('Login').exists).ok()
  

 })
 // Invalid Password 

 test('Login user with an Invalid password', async t=>{
await t 
   .typeText(Selector('#email'), 'abd1810000@hotmail.com')
   .typeText(Selector('#password'), '12345678bb')
   .click(Selector('#blogin'))
   .wait(5000)
   .expect(Selector('H2').withExactText('Login').exists).ok()
 })

 // Click on login button with filling out the credentials

 test('Not filling out the credentials', async t=>{
await t 
   
   .click(Selector('#blogin'))
   .wait(5000)
   .expect(Selector('H2').withExactText('Login').exists).ok()
 })
 // Invalid Email 

 test('Login user with invalid email', async t=>{
await t 
   .typeText(Selector('#email'), 'test@hotmail.com')
   .typeText(Selector('#password'), '12345678bb')
   .click(Selector('#blogin'))
   .wait(5000)
   .expect(Selector('H2').withExactText('Login').exists).ok()
 });
 

 


