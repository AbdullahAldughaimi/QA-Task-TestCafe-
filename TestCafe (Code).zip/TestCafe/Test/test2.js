
 import { Selector } from "testcafe";
 fixture `Auatomate Registration`

  // Invalid phone format 
  .page ('http://localhost/carrental/signup-user.php')
  test('Invalid phone format', async t=>{
     await t 
     .typeText(Selector('#names'), 'Abdullah') 
     .typeText(Selector('#email'), 'abd181@live.com')   
     .typeText(Selector('#phone'), '1234567890')
     .typeText(Selector('#password'), '12345678Aa')
     .typeText(Selector('#cpassword'), '12345678Aa')
  
     .click(Selector('#bsignup'))
     .wait(5000)
     .expect(Selector('H2').withExactText('Signup').exists).ok();
    
  })
  // Invalid password format  
    test('Invalid password format', async t=>{
    await t 
    .typeText(Selector('#names'), 'Abdullah') 
    .typeText(Selector('#email'), 'abd181@live.com')   
    .typeText(Selector('#phone'), '0563810111')
    .typeText(Selector('#password'), '123')
    .typeText(Selector('#cpassword'), '123')
    .click(Selector('#bsignup'))
    .wait(5000)
    .expect(Selector('H2').withExactText('Signup').exists).ok(); 
 })
 // Not filling out all the info

 
 test('Not filling out all the info ', async t=>{
    await t 
   // .typeText(Selector('#names'), 'Abdullah') 
    .typeText(Selector('#email'), 'abd181@live.com')   
    .typeText(Selector('#phone'), '0563810177')
    .typeText(Selector('#password'), '12345678Aa')
    .typeText(Selector('#cpassword'), '12345678Aa')
 
    .click(Selector('#bsignup'))
    .wait(5000)
    .expect(Selector('H2').withExactText('Signup').exists).ok(); 
 })
 // Already a member? 
  test('Already a member?', async t=>{
    await t 
    .wait(5000)
    .click(Selector('#AlreadyMember'))
    .wait(5000)
    .expect(Selector('H2').withExactText('Login').exists).ok(); 

 });
 

