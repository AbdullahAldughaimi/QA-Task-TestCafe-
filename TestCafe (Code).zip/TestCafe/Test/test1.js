import { Selector } from "testcafe";
fixture `Auatomate Registration`
 .page ('http://localhost/carrental/signup-user.php')
// User registration (valid)
 test('User registration (valid)', async t=>{
    await t 

    .typeText(Selector('#names'), 'Abdullah') 
    .typeText(Selector('#email'), 'abd1810000@hotmail.com')   
    .typeText(Selector('#phone'), '0563810177')
    .typeText(Selector('#password'), '12345678Aa')
    .typeText(Selector('#cpassword'), '12345678Aa')

    .click(Selector('#bsignup'))
    .wait(5000)
    .expect(Selector('H2').withExactText('Login').exists).ok();
   
 })
 // Already Phone & Email exist 


 test('Already Phone & Email exist ', async t=>{
    await t 

    .typeText(Selector('#names'), 'Abdullah') 
    .typeText(Selector('#email'), 'abd1810000@hotmail.com')   
    .typeText(Selector('#phone'), '0563810177')
    .typeText(Selector('#password'), '12345678Aa')
    .typeText(Selector('#cpassword'), '12345678Aa')

    .click(Selector('#bsignup'))
    .wait(5000)
    .expect(Selector('H2').withExactText('Signup').exists).ok();
   
 })

 // Password does not match


test('Password does not match', async t=>{
   await t 

   .typeText(Selector('#names'), 'Abdullah') 
   .typeText(Selector('#email'), 'abd181@live.com')   
   .typeText(Selector('#phone'), '0563810133')
   .typeText(Selector('#password'), '12345678Aa')
   .typeText(Selector('#cpassword'), 'a23f5678Ac')

   .click(Selector('#bsignup'))
   .wait(5000)
   .expect(Selector('H2').withExactText('Signup').exists).ok();
  
})

 // Phone already exists  
 
 test('Phone already exists', async t=>{
    await t 
    .typeText(Selector('#names'), 'Abdullah') 
    .typeText(Selector('#email'), 'abd181@live.com')   
    .typeText(Selector('#phone'), '0563810189')
    .typeText(Selector('#password'), '12345678Aa')
    .typeText(Selector('#cpassword'), '12345678Aa')
 
    .click(Selector('#bsignup'))
    .wait(5000)
    .expect(Selector('H2').withExactText('Signup').exists).ok();
   
 })
  // Email already exists  
 
  test('Email already exists', async t=>{
     await t 
     .typeText(Selector('#names'), 'Abdullah') 
     .typeText(Selector('#email'), 'abd1810000@gmail.com')   
     .typeText(Selector('#phone'), '0563810155')
     .typeText(Selector('#password'), '12345678Aa')
     .typeText(Selector('#cpassword'), '12345678Aa')
  
     .click(Selector('#bsignup'))
     .wait(5000)
     .expect(Selector('H2').withExactText('Signup').exists).ok();
    
  });
